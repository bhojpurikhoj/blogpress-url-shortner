<?php include('template_declare.php'); ?>
<?php include('template_header.php'); ?>

<div class="tw-card row searchContainer col s12 m12 l12 xl12 title_white" style="color:black;">
   

     <ul class=collection>
         <li class=collection-item>
       		<p class=tag>1</p>
        	<p>Please update your config file with your current Mysql database
        	<div class=chip>
        	   config.php
        	</div>
        	</li>
        	
        <li class=collection-item>
       		<p class=tag>2</p>
        	<p>Please click to Install once and install this on your server. After installation please delete install.php 
        	<div class=chip>
        	    <a target="_blank" href="install.php"> <i class="fa fa-plus-square-o fa-fw fa-lg m-r-3"></i> Install Script</a>
        	</div>
        	
        	
        	
        </li>	  	
        <li class=collection-item>
       		<p class=tag>3</p>
        	<p>After installation, please click on Admin
        	<div class=chip>
        	    <a target="_blank" href="admin.php"> <i class="fa fa-dashboard fa-fw fa-lg m-r-3"></i> Admin Dashboard</a>
        	</div>
        	</div>
        	</li>
        	
        	
        	</ul>
     
      </div>
                   
<?php include('template_footer.php'); ?>