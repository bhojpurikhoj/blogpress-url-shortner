<?php include('config.php'); ?>
<?php include('config.settings.php'); ?>